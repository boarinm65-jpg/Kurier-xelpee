package com.courierhelper.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.SharedPreferences;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Optional, user-enabled. Reads only Glovo offer text; never presses buttons. */
public class OfferAccessibilityService extends AccessibilityService {
 private long lastRead=0;
 private static final Pattern MONEY=Pattern.compile("(?i)(\\d{1,4}[,.]\\d{1,2})\\s*(?:zł|pln)");
 private static final Pattern KM=Pattern.compile("(?i)(\\d{1,3}[,.]\\d{1,2})\\s*km");
 @Override public void onAccessibilityEvent(AccessibilityEvent event){
  if(event==null||event.getPackageName()==null)return;
  String pkg=event.getPackageName().toString().toLowerCase(Locale.ROOT);
  if(!pkg.contains("glovo"))return;
  if(System.currentTimeMillis()-lastRead<1700)return;
  lastRead=System.currentTimeMillis();
  AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
  StringBuilder b=new StringBuilder();collect(root,b,0);String text=b.toString();
  if(!(text.toLowerCase(Locale.ROOT).contains("przyjm")||text.toLowerCase(Locale.ROOT).contains("accept")||text.toLowerCase(Locale.ROOT).contains("akcept")||text.toLowerCase(Locale.ROOT).contains("принять")))return;
  Matcher m=MONEY.matcher(text),d=KM.matcher(text);if(!m.find()||!d.find())return;
  try{
   float pay=Float.parseFloat(m.group(1).replace(',','.'));
   float km=Float.parseFloat(d.group(1).replace(',','.'));
   if(pay<=0||pay>1000||km<=0||km>100)return;
   SharedPreferences p=getSharedPreferences("offer",0);
   p.edit().putFloat("pay",pay).putFloat("km",km).putLong("at",System.currentTimeMillis()).apply();
  }catch(Exception ignored){}
 }
 private static void collect(AccessibilityNodeInfo n,StringBuilder out,int depth){
  if(n==null||depth>12||out.length()>20000)return;
  CharSequence t=n.getText();if(t!=null)out.append(t).append(' ');
  for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){collect(c,out,depth+1);c.recycle();}}
 }
 @Override public void onInterrupt(){}
}
