package com.courierhelper.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.util.Locale;

/** Native foreground GPS recording with optional lightweight overlay. */
public class TrackingService extends Service implements LocationListener {
 public static final String START="COURIER_START", STOP="COURIER_STOP", REFRESH="COURIER_REFRESH";
 private static final String CHANNEL="courier_tracking", PREFS="native_tracking";
 private LocationManager manager;
 private Location lastAccepted;
 private WindowManager wm;
 private ImageView bubble;
 private LinearLayout card;
 private TextView cardText;
 private WindowManager.LayoutParams bubbleParams,cardParams;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable refreshUi=new Runnable(){@Override public void run(){refreshCard();handler.postDelayed(this,2500);}};
 private android.content.SharedPreferences gps;

 @Override public void onCreate(){super.onCreate();gps=getSharedPreferences(PREFS,0);manager=(LocationManager)getSystemService(LOCATION_SERVICE);
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  NotificationChannel ch=new NotificationChannel(CHANNEL,"Активная смена и GPS",NotificationManager.IMPORTANCE_LOW);
  getSystemService(NotificationManager.class).createNotificationChannel(ch);
  handler.post(refreshUi);
 }
 private Notification notification(){
  Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
  PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
   .setContentTitle("COURIER HELPER · смена идёт")
   .setContentText("GPS записывает километры даже при закрытом экране")
   .setContentIntent(pi).setOngoing(true).build();
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){String action=intent==null?"":intent.getAction();
  if(STOP.equals(action)){stopTracking();return START_NOT_STICKY;}
  if(REFRESH.equals(action)){if(gps.getBoolean("active",false))showBubble();else stopSelf();return START_STICKY;}
  if(!START.equals(action)&&!gps.getBoolean("active",false)){stopSelf();return START_NOT_STICKY;}
  if(!gps.getBoolean("active",false)){
   new java.io.File(getFilesDir(),"courier_route.csv").delete();
   lastAccepted=null;
   gps.edit().putFloat("km",0f).putBoolean("active",true).apply();
  }
  startForeground(22,notification());
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   gps.edit().putBoolean("active",false).apply();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;
  }
  try{manager.removeUpdates(this);manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,3500,4f,this,Looper.getMainLooper());}
  catch(SecurityException e){gps.edit().putBoolean("active",false).apply();stopSelf();return START_NOT_STICKY;}
  catch(IllegalArgumentException e){ /* Device may have GPS disabled; user can enable it in settings */ }
  showBubble();return START_STICKY;
 }
 @Override public void onLocationChanged(Location l){
  if(!gps.getBoolean("active",false)||!l.hasAccuracy()||l.getAccuracy()>70||l.getAccuracy()<0)return;
  if(lastAccepted!=null){
   float meters=lastAccepted.distanceTo(l);
   float dt=(l.getElapsedRealtimeNanos()-lastAccepted.getElapsedRealtimeNanos())/1e9f;
   float minDistance=Math.max(5f,Math.min(16f,(lastAccepted.getAccuracy()+l.getAccuracy())*.3f));
   if(dt<1||meters<minDistance||meters/dt>18f)return;
   gps.edit().putFloat("km",gps.getFloat("km",0)+meters/1000f).apply();
  }
  lastAccepted=new Location(l);
  try(java.io.FileWriter file=new java.io.FileWriter(new java.io.File(getFilesDir(),"courier_route.csv"),true)){
   file.write(String.format(java.util.Locale.US,"%d,%.7f,%.7f,%.1f\n",l.getTime(),l.getLatitude(),l.getLongitude(),l.getAccuracy()));
  }catch(java.io.IOException ignored){}
  gps.edit().putFloat("lat",(float)l.getLatitude()).putFloat("lon",(float)l.getLongitude()).putFloat("accuracy",l.getAccuracy()).apply();
 }
 private void stopTracking(){gps.edit().putBoolean("active",false).apply();manager.removeUpdates(this);removeOverlay();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
 @Override public void onDestroy(){manager.removeUpdates(this);removeOverlay();handler.removeCallbacks(refreshUi);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
 private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
 private GradientDrawable shape(int bg,int border,int radius){GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));d.setStroke(dp(2),border);return d;}
 private WindowManager.LayoutParams params(int width,int height){WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.x=getResources().getDisplayMetrics().widthPixels-dp(80);p.y=dp(180);return p;}
 private void showBubble(){if(!Settings.canDrawOverlays(this)||!gps.getBoolean("active",false))return;
  if(bubble!=null||card!=null)return;
  bubble=new ImageView(this);bubble.setImageResource(R.drawable.bear_bike);bubble.setScaleType(ImageView.ScaleType.CENTER_CROP);
  bubble.setBackground(shape(Color.rgb(28,12,51),Color.rgb(169,67,250),38));bubble.setClipToOutline(true);
  bubbleParams=params(dp(66),dp(66));
  final float[] start=new float[2], down=new float[2];final boolean[] dragged={false};
  bubble.setOnTouchListener((v,e)->{switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN: down[0]=e.getRawX();down[1]=e.getRawY();start[0]=bubbleParams.x;start[1]=bubbleParams.y;dragged[0]=false;return true;
   case MotionEvent.ACTION_MOVE: if(Math.abs(e.getRawX()-down[0])+Math.abs(e.getRawY()-down[1])>dp(10))dragged[0]=true;
    bubbleParams.x=(int)(start[0]+e.getRawX()-down[0]);bubbleParams.y=(int)(start[1]+e.getRawY()-down[1]);
    try{wm.updateViewLayout(bubble,bubbleParams);}catch(Exception ignored){}return true;
   case MotionEvent.ACTION_UP: if(!dragged[0])showCard();return true;
   default:return false;
  }});
  try{wm.addView(bubble,bubbleParams);}catch(Exception e){bubble=null;}
 }
 private void showCard(){removeBubble();if(!Settings.canDrawOverlays(this))return;
  card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));
  card.setBackground(shape(Color.rgb(27,12,46),Color.rgb(163,74,253),20));
  TextView title=new TextView(this);title.setText("🐻🚲  COURIER HELPER  ·  ✕");title.setTextColor(Color.rgb(225,181,255));title.setTextSize(15);title.setTypeface(null,1);card.addView(title);
  title.setOnClickListener(v->{removeCard();showBubble();});
  cardText=new TextView(this);cardText.setTextColor(Color.WHITE);cardText.setTextSize(14);cardText.setPadding(0,dp(10),0,dp(6));card.addView(cardText);
  refreshCard();
  cardParams=params(dp(310),WindowManager.LayoutParams.WRAP_CONTENT);cardParams.x=Math.max(dp(8),getResources().getDisplayMetrics().widthPixels-dp(320));
  try{wm.addView(card,cardParams);}catch(Exception e){card=null;cardText=null;showBubble();}
 }
 private void refreshCard(){if(cardText==null)return;
  android.content.SharedPreferences p=getSharedPreferences("offer",0);
  float pay=p.getFloat("pay",0),km=p.getFloat("km",0),cost=p.getFloat("cost",.25f);
  String rest=p.getString("restaurant", "Ресторан не определён");
  long time=p.getLong("at",0);
  String offer;
  if(pay>0&&km>0&&System.currentTimeMillis()-time<15*60*1000){
   float net=pay-km*cost,perKm=net/km;
   String rating=perKm>=2.3f?"🟣 Выгодный":perKm>=1.7f?"🟠 Средний":"🔴 Невыгодный";
   offer=String.format(Locale.forLanguageTag("ru-RU"),"%s заказ\n💰 %.2f zł  ·  %.2f км\nПосле расходов: %.2f zł  ·  %.2f zł/км",rating,pay,km,net,perKm);
  }else offer="Ожидаем предложение Glovo…\n(или введи вручную в приложении)";
  String toilet="?",wait="?";
  try{JSONObject notes=new JSONObject(getSharedPreferences("restaurant_notes",0).getString("notes","{}"));JSONObject n=notes.optJSONObject(rest.trim().toLowerCase(Locale.ROOT));if(n!=null){String t=n.optString("toilet","unknown");toilet="yes".equals(t)?"есть":"no".equals(t)?"нет":"?";wait=String.valueOf(n.optInt("wait",0))+" мин";}}catch(Exception ignored){}
  cardText.setText(String.format(Locale.forLanguageTag("ru-RU"),"Смена: %.2f км\n\n%s\n\n📍 %s\n🚻 Туалет: %s · ⏱ Ожидание: %s\n\nНажми на заголовок, чтобы свернуть",gps.getFloat("km",0),offer,rest,toilet,wait));
 }
 private void removeBubble(){if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}}
 private void removeCard(){if(card!=null){try{wm.removeView(card);}catch(Exception ignored){}card=null;cardText=null;}}
 private void removeOverlay(){removeBubble();removeCard();}
}
