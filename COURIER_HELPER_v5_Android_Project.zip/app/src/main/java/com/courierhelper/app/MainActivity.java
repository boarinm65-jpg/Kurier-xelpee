package com.courierhelper.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
 private WebView web;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private ValueCallback<Uri[]> fileCallback;
 private String pendingBackup=null;
 private static final int GPS_REQUEST=10, FILE_REQUEST=11, BACKUP_REQUEST=13;
 private boolean pendingStart=false;
 private final Runnable tick=new Runnable(){@Override public void run(){
  if(web!=null){
   float km=getSharedPreferences("native_tracking",0).getFloat("km",0f);
   float lat=getSharedPreferences("native_tracking",0).getFloat("lat",0f);
   float lon=getSharedPreferences("native_tracking",0).getFloat("lon",0f);
   float accuracy=getSharedPreferences("native_tracking",0).getFloat("accuracy",0f);
   web.evaluateJavascript(String.format(Locale.US,"window.courierSync&&window.courierSync(%.4f,%.7f,%.7f,%.1f)",km,lat,lon,accuracy),null);
  }
  handler.postDelayed(this,2000);
 }};
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);setContentView(web);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);
  web.addJavascriptInterface(new Bridge(),"Android");
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;
    try{Intent pick=new Intent(Intent.ACTION_GET_CONTENT);pick.setType("application/json");pick.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(pick,"Выберите резервную копию"),FILE_REQUEST);return true;}
    catch(Exception e){fileCallback=null;return false;}
   }
  });
  web.loadUrl("file:///android_asset/index.html");handler.postDelayed(tick,2500);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},12);
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==BACKUP_REQUEST && pendingBackup!=null){
   if(result==RESULT_OK && data!=null && data.getData()!=null){
    try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){
     if(out!=null){out.write(pendingBackup.getBytes(java.nio.charset.StandardCharsets.UTF_8));Toast.makeText(this,"Резервная копия сохранена",Toast.LENGTH_SHORT).show();}
    }catch(Exception e){Toast.makeText(this,"Ошибка сохранения: "+e.getMessage(),Toast.LENGTH_LONG).show();}
   }
   pendingBackup=null;
  }
  if(request==FILE_REQUEST && fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK && data!=null && data.getData()!=null?new Uri[]{data.getData()}:null);fileCallback=null;}
 }
 @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] grants){super.onRequestPermissionsResult(req,permissions,grants);
  if(req==GPS_REQUEST && pendingStart){pendingStart=false;if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)startServiceNow();else Toast.makeText(this,"Для фонового GPS разрешите точное местоположение",Toast.LENGTH_LONG).show();}
 }
 @Override protected void onDestroy(){handler.removeCallbacks(tick);if(web!=null){web.destroy();web=null;}super.onDestroy();}
 private void startServiceNow(){Intent i=new Intent(this,TrackingService.class);i.setAction(TrackingService.START);try{startForegroundService(i);}catch(Exception e){Toast.makeText(this,"Ошибка запуска GPS: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
 private void startGps(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){pendingStart=true;requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},GPS_REQUEST);return;}startServiceNow();}
 private void stopGps(){Intent i=new Intent(this,TrackingService.class);i.setAction(TrackingService.STOP);startService(i);}
 @Override protected void onResume(){super.onResume();
  if(getSharedPreferences("native_tracking",0).getBoolean("active",false)&&Settings.canDrawOverlays(this)){
   Intent i=new Intent(this,TrackingService.class);i.setAction(TrackingService.REFRESH);startService(i);
  }
 }
 public class Bridge {
  @JavascriptInterface public void startTracking(){runOnUiThread(()->startGps());}
  @JavascriptInterface public void stopTracking(){runOnUiThread(()->stopGps());}
  @JavascriptInterface public void requestOverlay(){runOnUiThread(()->{
    if(!Settings.canDrawOverlays(MainActivity.this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}
    else {Toast.makeText(MainActivity.this,"Плавающее окно разрешено",Toast.LENGTH_SHORT).show();Intent i=new Intent(MainActivity.this,TrackingService.class);i.setAction(TrackingService.REFRESH);startService(i);}
  });}
  @JavascriptInterface public void requestOfferReading(){runOnUiThread(()->{Toast.makeText(MainActivity.this,"Найдите Courier Helper и включите доступ. Чтение только Glovo, без нажатия кнопок",Toast.LENGTH_LONG).show();startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});}
  @JavascriptInterface public void saveRestaurant(String name,String toilet,int wait){try{
   name=name.trim().toLowerCase(Locale.ROOT);if(name.isEmpty()||name.length()>120)return;
   JSONObject j=new JSONObject(getSharedPreferences("restaurant_notes",0).getString("notes","{}"));
   JSONObject value=new JSONObject();value.put("toilet",toilet);value.put("wait",Math.max(0,Math.min(120,wait)));
   j.put(name,value);getSharedPreferences("restaurant_notes",0).edit().putString("notes",j.toString()).apply();
  }catch(Exception ignored){}}
  @JavascriptInterface public void setManualOffer(String restaurant,double pay,double km){if(pay<=0||km<=0)return;
   getSharedPreferences("offer",0).edit().putString("restaurant",restaurant.substring(0,Math.min(120,restaurant.length()))).putFloat("pay",(float)pay).putFloat("km",(float)km).putLong("at",System.currentTimeMillis()).apply();
  }
  @JavascriptInterface public String getNativeRouteJson(){
   org.json.JSONArray points=new org.json.JSONArray();
   java.io.File file=new java.io.File(getFilesDir(),"courier_route.csv");
   if(!file.exists())return "[]";
   try(java.io.BufferedReader r=new java.io.BufferedReader(new java.io.FileReader(file))){
    String line;int n=0;
    while((line=r.readLine())!=null&&n<12000){
     String[] v=line.split(",");if(v.length!=4)continue;
     org.json.JSONObject p=new org.json.JSONObject();
     p.put("at",Long.parseLong(v[0]));p.put("lat",Double.parseDouble(v[1]));p.put("lon",Double.parseDouble(v[2]));p.put("accuracy",Double.parseDouble(v[3]));points.put(p);n++;
    }
   }catch(Exception ignored){}
   return points.toString();
  }
  @JavascriptInterface public void exportBackup(String json){runOnUiThread(()->{
   if(json.length()>10000000)return;
   pendingBackup=json;
   Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
   i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"courier_helper_backup.json");
   try{startActivityForResult(i,BACKUP_REQUEST);}catch(Exception e){pendingBackup=null;Toast.makeText(MainActivity.this,"Не удалось выбрать файл",Toast.LENGTH_LONG).show();}
  });}
  @JavascriptInterface public void setCostPerKm(double cost){getSharedPreferences("offer",0).edit().putFloat("cost",(float)Math.max(0,Math.min(5,cost))).apply();}
 }
}
