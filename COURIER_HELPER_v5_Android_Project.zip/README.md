# COURIER HELPER 5.0 — Android beta source

**Not a tested APK.** Android project for an on-device beta. Existing GitHub Pages site remains unchanged. Build via GitHub Actions (Android APK workflow) or Android Studio.

- Main screen: V2 light interface; local shift, earnings, expense, manual orders.
- Background GPS: native foreground location service with persistent notification; Android may restrict it without battery exemption. Starting service requires user location permission.
- Floating purple bubble/card: manually enable *Display over other apps*. Bear-on-bicycle asset cropped from our agreed draft, not polished icon yet.
- Offer analysis: optional Accessibility service reads Glovo's **visible** offer text only after user manually enables it. It never clicks accept/decline. Parsing is experimental and can fail if Glovo changes UI or restricts accessibility.
- Restaurant toilet/wait: **only on-device entries** currently. **No shared server database** connected, so don't claim crowdsourced data exists.
- Quests: first local income target; not a complete multi-period engine.
- Old website's localStorage cannot be read by native WebView. Original data is *not* automatically migrated. Backup/export from old site is necessary before uninstalling; an import/migration workflow should be tested before relying on it.
- Android WebView file:// CSV Blob downloads may not work; export should be improved. GPS route is a schematic, not a street map.
- This prototype needs full compilation and real-world GPS/overlay tests; it is **not production ready**.

### Build on GitHub
Upload extracted project files to repository root, including `.github/workflows/android-apk.yml` and `app/`. Open **Actions → Build Courier Helper APK → Run workflow**; download uploaded artifact `COURIER-HELPER-v5-debug-apk` then install `app-debug.apk`.

### Permissions
Allow precise location and while-in-use permission. The foreground service continues after locking screen while Android permits. For overlay, use the purple overlay permission control. For experimental offer reader, manually enable Accessibility service. Keep note that Accessibility has broad screen-reading capabilities; service code filters to Glovo and stores only parsed numbers.
